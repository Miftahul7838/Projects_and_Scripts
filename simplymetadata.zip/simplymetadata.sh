#!/bin/bash

dir="$1"

echo "-------------------- Metadata of Each File --------------------"

exiftool $dir

echo "-------------------- Unique Tags --------------------"

exiftool -a -u -g1 $dir | grep -oP -- "----\K[^-]*(?=----)" | sort -u


echo "-------------------- File Element Changeable --------------------"

files=$(ls $dir)

touch temp.txt
touch temp_scrub.txt

for file in $files; do
	echo "---------- $file ----------"
	tFile="$dir/$file"
	exiftool $tFile > ./temp.txt
	exiftool -all= $tFile
	exiftool $tFile > ./temp_scrub.txt
	diff ./temp.txt ./temp_scrub.txt
done

rm -f ./temp.txt ./temp_scrub.txt
