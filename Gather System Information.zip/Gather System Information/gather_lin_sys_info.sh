#!/bin/bash

# Run ps aux command and display the output
# Author: Jason Ricca
echo "### Process Information ###"
ps aux

# Run getent passwd command and display the output
# Author: Anthony Swierkosz
echo -e "\n### User Information ###"
getent passwd

# Run dig command and display the output
# Author: Karin Sannomiya
echo -e "\n### DNS Information ###"
dig 127.0.0.1

# Run ss command and display the output
# Author: Tyler Dubay
echo -e "\n### Network Connection Information ###"
ss